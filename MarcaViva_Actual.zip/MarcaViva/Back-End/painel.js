// Lógica da página painel.html

// ==========================================================================
// SESSÃO LOCAL — lê os dados de sessão gravados por login.js após a
// autenticação no servidor e preenche o cabeçalho do painel.
// ==========================================================================
(function carregarSessao() {
  const sessao = sessionStorage.getItem('marcaviva_sessao');

  if (!sessao) {
    window.location.href = "login.html";
    return;
  }

  try {
    const dados = JSON.parse(sessao);
    const elNomeEmpresa = document.getElementById('db-nome-empresa');
    const elNicho = document.getElementById('db-nicho-empresa');
    if (elNomeEmpresa) elNomeEmpresa.textContent = dados.empresa || 'Sua Empresa';
    if (elNicho) elNicho.textContent = dados.nicho || 'Não informado';
  } catch (e) {
    window.location.href = "login.html";
  }
})();

function fazerLogout() {
  sessionStorage.removeItem('marcaviva_sessao');
  window.location.href = "login.html";
}

// ==========================================================================
// NAVEGAÇÃO — abas do painel + grupos colapsáveis da sidebar
// ==========================================================================

// Mapa de qual grupo da sidebar cada aba pertence (para auto-expandir e
// destacar a categoria ativa)
const MAPA_GRUPO_DA_ABA = {
  'psico-cores': 'inteligencia',
  'mentor-ia': 'inteligencia',
  'copys-magneticas': 'marketing',
  'impulsionador-social': 'marketing',
  'estudio-conteudo': 'marketing',
  'arquitetura-marca': 'marketing',
  'radar-negocios': 'negocios',
  'radar-oportunidades': 'negocios',
  'gerador-propostas': 'negocios',
  'organizador-projetos': 'organizacao',
  'calculadora-pj': 'organizacao'
};

function alternarAbas(event, idSecao) {
  if (event) event.preventDefault();

  document.querySelectorAll('.dashboard-section').forEach((el) => el.classList.add('section-hidden'));
  document.querySelectorAll('.menu-item').forEach((el) => el.classList.remove('active'));

  const secao = document.getElementById(idSecao);
  if (secao) secao.classList.remove('section-hidden');

  const itemClicado = event ? event.currentTarget : document.querySelector('[data-tab="' + idSecao + '"]');
  if (itemClicado) itemClicado.classList.add('active');

  // Expande e destaca o grupo correspondente na sidebar
  const grupoAlvo = MAPA_GRUPO_DA_ABA[idSecao];
  document.querySelectorAll('.menu-group').forEach((grupo) => {
    grupo.classList.remove('group-active');
  });
  if (grupoAlvo) {
    const grupoEl = document.querySelector('.menu-group[data-group="' + grupoAlvo + '"]');
    if (grupoEl) {
      grupoEl.classList.add('group-open', 'group-active');
    }
  }

  // Contabiliza uso da ferramenta para a Visão Geral
  registrarUsoFerramenta(idSecao);

  if (window.lucide) lucide.createIcons();
}

function alternarGrupo(botao) {
  const grupo = botao.closest('.menu-group');
  if (grupo) grupo.classList.toggle('group-open');
}

// Copia o texto de um card de copy para a área de transferência
function copiarTexto(botao) {
  const corpo = botao.closest('.copy-card, .resultado-card').querySelector('.copy-card-body, .resultado-card-body');
  navigator.clipboard.writeText(corpo.textContent.trim()).then(() => {
    const textoOriginal = botao.innerHTML;
    botao.innerHTML = '<i data-lucide="check"></i> Copiado';
    if (window.lucide) lucide.createIcons();
    setTimeout(() => { botao.innerHTML = textoOriginal; if (window.lucide) lucide.createIcons(); }, 1500);
  });
}

// Exporta o conteúdo principal do painel como PDF
function gerarPDFCompleto() {
  const conteudo = document.querySelector('.main-content');
  if (window.html2pdf && conteudo) {
    html2pdf().set({ filename: 'relatorio-marcaviva.pdf', margin: 10 }).from(conteudo).save();
  }
}

// ==========================================================================
// PERFIL DO NEGÓCIO — estrutura central usada por todas as ferramentas
// ==========================================================================

const PERFIL_KEY = 'marcaviva_perfil_negocio';

function carregarPerfil() {
  try {
    const bruto = localStorage.getItem(PERFIL_KEY);
    return bruto ? JSON.parse(bruto) : null;
  } catch (e) {
    return null;
  }
}

function perfilEstaVazio(perfil) {
  if (!perfil) return true;
  return !perfil.area && !perfil.profissao && !perfil.servicos;
}

function abrirPerfil() {
  const perfil = carregarPerfil() || {};
  document.getElementById('perfilArea').value = perfil.area || '';
  document.getElementById('perfilProfissao').value = perfil.profissao || '';
  document.getElementById('perfilHabilidades').value = perfil.habilidades || '';
  document.getElementById('perfilExperiencia').value = perfil.experiencia || 'iniciante';
  document.getElementById('perfilEstiloComunicacao').value = perfil.estiloComunicacao || 'profissional';
  document.getElementById('perfilServicos').value = perfil.servicos || '';
  document.getElementById('perfilPublico').value = perfil.publico || '';
  document.getElementById('perfilObjetivo').value = perfil.objetivo || '';
  document.getElementById('perfilFaixaPreco').value = perfil.faixaPreco || '';
  document.getElementById('modalPerfil').style.display = 'flex';
}

function fecharPerfil() {
  document.getElementById('modalPerfil').style.display = 'none';
}

function fecharModalSeClicarFora(event, idModal) {
  if (event.target.id === idModal) {
    document.getElementById(idModal).style.display = 'none';
  }
}

function salvarPerfil(event) {
  event.preventDefault();
  const perfil = {
    area: document.getElementById('perfilArea').value.trim(),
    profissao: document.getElementById('perfilProfissao').value.trim(),
    habilidades: document.getElementById('perfilHabilidades').value.trim(),
    experiencia: document.getElementById('perfilExperiencia').value,
    estiloComunicacao: document.getElementById('perfilEstiloComunicacao').value,
    servicos: document.getElementById('perfilServicos').value.trim(),
    publico: document.getElementById('perfilPublico').value.trim(),
    objetivo: document.getElementById('perfilObjetivo').value.trim(),
    faixaPreco: document.getElementById('perfilFaixaPreco').value.trim()
  };
  localStorage.setItem(PERFIL_KEY, JSON.stringify(perfil));
  fecharPerfil();
  atualizarContextoPerfil();
}

// Atualiza o chip de contexto no topo do painel e o texto de boas-vindas do Mentor IA
function atualizarContextoPerfil() {
  const perfil = carregarPerfil();
  const chip = document.getElementById('chipPerfilContexto');
  const chipTexto = document.getElementById('chipPerfilTexto');
  if (!chip || !chipTexto) return;

  if (perfilEstaVazio(perfil)) {
    chip.classList.remove('perfil-ativo');
    chipTexto.textContent = 'Configure seu Perfil do Negócio para respostas personalizadas em todas as ferramentas.';
    return;
  }

  chip.classList.add('perfil-ativo');
  const partes = [perfil.area, perfil.servicos, perfil.publico].filter(Boolean);
  chipTexto.textContent = 'Perfil ativo: ' + partes.join(' · ');

  const boasVindas = document.getElementById('chatMsgBoasVindas');
  if (boasVindas) {
    boasVindas.innerHTML = 'Olá! Cruzei os dados do seu Perfil do Negócio (' + (perfil.area || 'seu segmento') +
      (perfil.servicos ? ' · ' + perfil.servicos : '') +
      '). Posso te ajudar com decisões de negócio, precificação, estratégias para conseguir clientes, organização, planejamento, posicionamento e marketing. Como posso te ajudar agora?';
  }
}

// ==========================================================================
// VISÃO GERAL — agrega dados das outras ferramentas
// ==========================================================================

const FERRAMENTAS_USADAS_KEY = 'marcaviva_ferramentas_usadas';
const CONTEUDOS_RECENTES_KEY = 'marcaviva_conteudos_recentes';

function registrarUsoFerramenta(idSecao) {
  if (idSecao === 'visao-geral') { atualizarVisaoGeral(); return; }
  try {
    const usadas = new Set(JSON.parse(localStorage.getItem(FERRAMENTAS_USADAS_KEY) || '[]'));
    usadas.add(idSecao);
    localStorage.setItem(FERRAMENTAS_USADAS_KEY, JSON.stringify([...usadas]));
  } catch (e) { /* ignora */ }
}

function registrarConteudoRecente(titulo, origem) {
  try {
    const lista = JSON.parse(localStorage.getItem(CONTEUDOS_RECENTES_KEY) || '[]');
    lista.unshift({ titulo, origem, data: new Date().toLocaleDateString('pt-BR') });
    localStorage.setItem(CONTEUDOS_RECENTES_KEY, JSON.stringify(lista.slice(0, 6)));
  } catch (e) { /* ignora */ }
}

function atualizarVisaoGeral() {
  // Projetos ativos e tarefas pendentes (Kanban)
  const tarefas = carregarTarefas();
  const ativas = tarefas.filter(t => t.coluna !== 'concluido');
  document.getElementById('ovProjetosAtivos').textContent = ativas.length;
  document.getElementById('ovTarefasPendentes').textContent = tarefas.filter(t => t.coluna === 'backlog' || t.coluna === 'andamento').length;

  // Ferramentas utilizadas
  const usadas = JSON.parse(localStorage.getItem(FERRAMENTAS_USADAS_KEY) || '[]');
  document.getElementById('ovFerramentasUsadas').textContent = usadas.length;

  // Lousa de organização (Pendências + Reuniões)
  renderizarLousa();

  if (window.lucide) lucide.createIcons();
}

// ==========================================================================
// LOUSA DE ORGANIZAÇÃO — Pendências &amp; Reuniões (Visão Geral)
// ==========================================================================

const LOUSA_KEY = 'marcaviva_lousa';

function carregarLousa() {
  try {
    const bruto = localStorage.getItem(LOUSA_KEY);
    if (bruto) return JSON.parse(bruto);
  } catch (e) { /* ignora */ }
  return [];
}

function salvarLousa(itens) {
  localStorage.setItem(LOUSA_KEY, JSON.stringify(itens));
}

function adicionarPendencia(event) {
  event.preventDefault();
  const texto = document.getElementById('novaPendenciaTexto').value.trim();
  if (!texto) return;
  const itens = carregarLousa();
  itens.push({
    id: 'p' + Date.now(),
    tipo: 'pendencia',
    texto,
    data: document.getElementById('novaPendenciaData').value,
    hora: '',
    feito: false
  });
  salvarLousa(itens);
  event.target.reset();
  renderizarLousa();
}

function adicionarReuniao(event) {
  event.preventDefault();
  const texto = document.getElementById('novaReuniaoTexto').value.trim();
  if (!texto) return;
  const itens = carregarLousa();
  itens.push({
    id: 'r' + Date.now(),
    tipo: 'reuniao',
    texto,
    data: document.getElementById('novaReuniaoData').value,
    hora: document.getElementById('novaReuniaoHora').value,
    feito: false
  });
  salvarLousa(itens);
  event.target.reset();
  renderizarLousa();
}

function alternarLousaItem(id) {
  const itens = carregarLousa();
  const item = itens.find(i => i.id === id);
  if (item) {
    item.feito = !item.feito;
    salvarLousa(itens);
    renderizarLousa();
  }
}

function removerLousaItem(id) {
  const itens = carregarLousa().filter(i => i.id !== id);
  salvarLousa(itens);
  renderizarLousa();
}

function formatarDataBr(data) {
  if (!data) return '';
  const [ano, mes, dia] = data.split('-');
  return dia && mes && ano ? `${dia}/${mes}` : data;
}

function montarCardLousa(item) {
  const card = document.createElement('div');
  card.className = 'lousa-item' + (item.feito ? ' done' : '');

  const metaPartes = [];
  if (item.data) {
    metaPartes.push(`<span class="${item.tipo === 'reuniao' ? 'meta-reuniao' : ''}"><i data-lucide="calendar"></i>${formatarDataBr(item.data)}</span>`);
  }
  if (item.hora) {
    metaPartes.push(`<span class="${item.tipo === 'reuniao' ? 'meta-reuniao' : ''}"><i data-lucide="clock"></i>${item.hora}</span>`);
  }

  card.innerHTML = `
    <div class="lousa-check" onclick="alternarLousaItem('${item.id}')"><i data-lucide="check"></i></div>
    <div class="lousa-item-main">
      <strong>${escapeHtml(item.texto)}</strong>
      ${metaPartes.length ? `<div class="lousa-item-meta">${metaPartes.join('')}</div>` : ''}
    </div>
    <button class="lousa-item-remove" onclick="removerLousaItem('${item.id}')" title="Remover"><i data-lucide="trash-2"></i></button>
  `;
  return card;
}

function renderizarLousa() {
  const itens = carregarLousa();

  const listaPendencias = document.getElementById('listaPendencias');
  const vazioPendencias = document.getElementById('pendenciasVazio');
  if (listaPendencias) {
    listaPendencias.innerHTML = '';
    const pendencias = itens.filter(i => i.tipo === 'pendencia');
    vazioPendencias.style.display = pendencias.length ? 'none' : 'block';
    pendencias.forEach(item => listaPendencias.appendChild(montarCardLousa(item)));
  }

  const listaReunioes = document.getElementById('listaReunioes');
  const vazioReunioes = document.getElementById('reunioesVazio');
  if (listaReunioes) {
    listaReunioes.innerHTML = '';
    const reunioes = itens.filter(i => i.tipo === 'reuniao');
    vazioReunioes.style.display = reunioes.length ? 'none' : 'block';
    reunioes.forEach(item => listaReunioes.appendChild(montarCardLousa(item)));
  }

  if (window.lucide) lucide.createIcons();
}

function escapeHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto || '';
  return div.innerHTML;
}

// ==========================================================================
// MENTOR IA — CHAT (respostas locais contextualizadas pelo Perfil do Negócio)
// ==========================================================================

// ==========================================================================
// MENTOR IA — CHAT (conversa real com o agente local via /api/mentor-ia)
// ==========================================================================

let historicoChatMentor = [];
let aguardandoRespostaIA = false;

function adicionarMensagemChat(texto, autor) {
  const historico = document.getElementById('chatHistorico');
  const msg = document.createElement('div');
  msg.className = 'msg-box ' + autor;
  msg.innerHTML = `<div class="msg-avatar">${autor === 'bot' ? 'AI' : 'Você'}</div><div class="msg-text">${texto}</div>`;
  historico.appendChild(msg);
  historico.scrollTop = historico.scrollHeight;
  return msg;
}

function mostrarDigitando() {
  const historico = document.getElementById('chatHistorico');
  const msg = document.createElement('div');
  msg.className = 'msg-box bot digitando';
  msg.id = 'msgDigitando';
  msg.innerHTML = `<div class="msg-avatar">AI</div><div class="msg-text"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>`;
  historico.appendChild(msg);
  historico.scrollTop = historico.scrollHeight;
}

function removerDigitando() {
  const msg = document.getElementById('msgDigitando');
  if (msg) msg.remove();
}

function atualizarStatusChat(texto, online) {
  const statusTexto = document.getElementById('chatStatusTexto');
  const dot = document.getElementById('chatDotStatus');
  if (statusTexto) statusTexto.textContent = texto;
  if (dot) dot.style.background = online ? 'var(--success)' : 'var(--danger)';
}

async function enviarMensagemLivreIA() {
  if (aguardandoRespostaIA) return;

  const input = document.getElementById('inputMensagemIA');
  const texto = input.value.trim();
  if (!texto) return;

  const perfil = carregarPerfil() || {};

  adicionarMensagemChat(escapeHtml(texto), 'user');
  historicoChatMentor.push({ autor: 'user', texto });
  input.value = '';

  aguardandoRespostaIA = true;
  document.getElementById('btnEnviarChat').disabled = true;
  mostrarDigitando();

  try {
    const resposta = await fetch('/api/mentor-ia', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mensagem: texto, historico: historicoChatMentor, perfil })
    });
    const dados = await resposta.json();

    removerDigitando();

    if (!resposta.ok || !dados.sucesso) {
      atualizarStatusChat('Agente local indisponível', false);
      adicionarMensagemChat(escapeHtml(dados.mensagem || 'Não consegui falar com o agente de IA agora.'), 'bot');
      return;
    }

    atualizarStatusChat(
      dados.fonte === 'ollama' ? 'Respondendo com Ollama (processamento local)' : 'Respondendo com o agente local',
      true
    );
    adicionarMensagemChat(escapeHtml(dados.resposta), 'bot');
    historicoChatMentor.push({ autor: 'bot', texto: dados.resposta });
  } catch (e) {
    removerDigitando();
    atualizarStatusChat('Agente local indisponível', false);
    adicionarMensagemChat('Não consegui me conectar ao agente de IA local. Verifique se o servidor está rodando.', 'bot');
  } finally {
    aguardandoRespostaIA = false;
    document.getElementById('btnEnviarChat').disabled = false;
    if (window.lucide) lucide.createIcons();
  }
}

function verificarTecla(event) {
  if (event.key === 'Enter') enviarMensagemLivreIA();
}

// ==========================================================================
// COPYS MAGNÉTICAS
// ==========================================================================

const TEMPLATES_COPY = {
  anuncio: (s, o, tomTxt) => `Pare de perder tempo com soluções genéricas. ${s} feito sob medida para o seu momento atual, com um processo claro do início ao fim. ${o}`,
  post: (s, o, tomTxt) => `Bastidores de um projeto real: ${s}. Cada detalhe pensado para gerar resultado, não só aparência. ${o}`,
  legenda: (s, o, tomTxt) => `${s} 👇\n\nMenos achismo, mais estratégia. ${o}`,
  whatsapp: (s, o, tomTxt) => `Oi! Vi que você pode se beneficiar de ${s}. Separei um horário rápido para te mostrar como funciona — ${o}. Posso te enviar mais detalhes?`,
  pagina_venda: (s, o, tomTxt) => `${s}\n\nPara quem está cansado de resultados medianos e quer um processo estruturado, com entregas claras e acompanhamento de perto. ${o}`,
  chamada: (s, o, tomTxt) => `${o || 'Fale agora com um especialista'} e descubra como ${s} pode transformar seu próximo passo.`,
  descricao_servico: (s, o, tomTxt) => `${s}: um serviço estruturado em etapas claras, com entregas objetivas e foco em resultado mensurável. ${o}`,
  prospeccao: (s, o, tomTxt) => `Olá! Notei uma oportunidade de aplicar ${s} no seu negócio. Já ajudei outros clientes a resolver esse mesmo desafio. Podemos conversar 15 minutos sobre isso? ${o}`
};

const ROTULOS_TOM = {
  profissional: 'tom profissional e direto',
  descontraido: 'tom descontraído e próximo',
  urgente: 'tom de urgência/escassez',
  inspirador: 'tom inspirador e aspiracional'
};

const ROTULOS_TIPO_COPY = {
  anuncio: 'Anúncio de Tráfego Pago',
  post: 'Post para Redes Sociais',
  legenda: 'Legenda de Instagram',
  whatsapp: 'Mensagem para WhatsApp',
  pagina_venda: 'Página de Venda',
  chamada: 'Chamada / CTA',
  descricao_servico: 'Descrição de Serviço',
  prospeccao: 'Mensagem de Prospecção'
};

function gerarCopyMagnetica(event) {
  event.preventDefault();
  const perfil = carregarPerfil() || {};
  const tipo = document.getElementById('copyTipo').value;
  const tom = document.getElementById('copyTom').value;
  const servicoInput = document.getElementById('copyServico').value.trim();
  const objetivo = document.getElementById('copyObjetivo').value.trim();

  const servico = servicoInput || perfil.servicos || 'o seu serviço';
  const objetivoTexto = objetivo ? `Ação recomendada: ${objetivo}.` : '';

  const gerador = TEMPLATES_COPY[tipo] || TEMPLATES_COPY.post;
  const texto = gerador(servico, objetivoTexto, ROTULOS_TOM[tom]);

  const container = document.getElementById('copyResultadoContainer');
  const card = document.createElement('div');
  card.className = 'resultado-card';
  card.innerHTML = `
    <div class="resultado-card-header">
      <span>${ROTULOS_TIPO_COPY[tipo]} · ${ROTULOS_TOM[tom]}</span>
      <button class="btn-copy" onclick="copiarTexto(this)"><i data-lucide="copy"></i> Copiar</button>
    </div>
    <div class="resultado-card-body">${escapeHtml(texto).replace(/\n/g, '<br>')}</div>
  `;
  container.prepend(card);
  registrarConteudoRecente(ROTULOS_TIPO_COPY[tipo], 'Copys Magnéticas');
  if (window.lucide) lucide.createIcons();
}

// ==========================================================================
// IMPULSIONADOR SOCIAL
// ==========================================================================

const ROTULOS_PLATAFORMA = {
  instagram: 'Instagram', tiktok: 'TikTok', reels: 'Reels', shorts: 'YouTube Shorts',
  whatsapp: 'WhatsApp', linkedin: 'LinkedIn'
};

function gerarImpulsionadorSocial(event) {
  event.preventDefault();
  const plataforma = document.getElementById('socialPlataforma').value;
  const objetivo = document.getElementById('socialObjetivo').value;
  const tema = document.getElementById('socialTema').value.trim() || 'seu trabalho';
  const container = document.getElementById('socialResultadoContainer');

  let corpo = '';
  let titulo = ROTULOS_PLATAFORMA[plataforma];

  if (objetivo === 'ideias_post') {
    titulo += ' · Ideias de Posts';
    corpo = `<ul>
      <li>Carrossel "3 erros comuns" relacionado a ${escapeHtml(tema)}</li>
      <li>Post de bastidor mostrando o processo por trás de ${escapeHtml(tema)}</li>
      <li>Depoimento ou resultado real de cliente</li>
      <li>Post de opinião/posicionamento sobre ${escapeHtml(tema)}</li>
      <li>Enquete ou pergunta para gerar comentários</li>
    </ul>`;
  } else if (objetivo === 'ideias_reels') {
    titulo += ' · Ideias de Vídeo Curto';
    corpo = `<ul>
      <li>Gancho nos 3 primeiros segundos: "Ninguém te conta isso sobre ${escapeHtml(tema)}"</li>
      <li>Vídeo de transformação (antes/depois)</li>
      <li>Passo a passo rápido em 3 etapas</li>
      <li>Mito vs. verdade sobre ${escapeHtml(tema)}</li>
      <li>Bastidor real de um dia de trabalho</li>
    </ul>`;
  } else if (objetivo === 'calendario') {
    titulo += ' · Calendário de Conteúdo (7 dias)';
    const dias = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
    const pautas = ['Bastidor do processo', 'Dica rápida', 'Depoimento/resultado', 'Conteúdo educativo', 'Chamada para ação (oferta)', 'Conteúdo leve/pessoal', 'Recapitulação da semana'];
    corpo = `<table class="mini-tabela"><thead><tr><th>Dia</th><th>Pauta sugerida</th></tr></thead><tbody>` +
      dias.map((d, i) => `<tr><td>${d}</td><td>${pautas[i]} — ${escapeHtml(tema)}</td></tr>`).join('') +
      `</tbody></table>`;
  } else if (objetivo === 'hashtags') {
    titulo += ' · Hashtags Estratégicas';
    const base = tema.toLowerCase().replace(/[^a-z0-9à-ú\s]/gi, '').split(/\s+/).filter(Boolean);
    const tags = [...new Set([...base.map(p => '#' + p), '#marcaviva', '#pj', '#autonomo', '#empreendedorismo', '#freelancer'])];
    corpo = `<div class="chips-row">${tags.map(t => `<span class="chip-tag">${t}</span>`).join('')}</div>`;
  } else {
    titulo += ' · CTAs de Engajamento';
    corpo = `<ul>
      <li>"Comenta AQUI se isso também acontece com você 👇"</li>
      <li>"Salva esse post pra não perder depois"</li>
      <li>"Manda pra alguém que precisa ler isso sobre ${escapeHtml(tema)}"</li>
      <li>"Me conta nos comentários: qual é o seu maior desafio com ${escapeHtml(tema)}?"</li>
    </ul>`;
  }

  const card = document.createElement('div');
  card.className = 'resultado-card';
  card.innerHTML = `<div class="resultado-card-header"><span>${titulo}</span></div><div class="resultado-card-body">${corpo}</div>`;
  container.prepend(card);
  registrarConteudoRecente(titulo, 'Impulsionador Social');
  if (window.lucide) lucide.createIcons();
}

// ==========================================================================
// ESTÚDIO DE CONTEÚDO
// ==========================================================================

const ROTULOS_FORMATO_ESTUDIO = {
  roteiro: 'Roteiro de Vídeo Curto', titulo: 'Títulos', descricao: 'Descrição',
  gancho: 'Ganchos (Hooks)', cena: 'Estrutura de Cenas', educativo: 'Conteúdo Educativo', comercial: 'Conteúdo Comercial'
};

function gerarEstudioConteudo(event) {
  event.preventDefault();
  const formato = document.getElementById('estudioFormato').value;
  const tema = document.getElementById('estudioTema').value.trim() || 'seu tema';
  const container = document.getElementById('estudioResultadoContainer');
  let corpo = '';

  if (formato === 'roteiro') {
    corpo = `<ul>
      <li><strong>Gancho (0-3s):</strong> "Se você trabalha com isso, precisa ver o que descobri sobre ${escapeHtml(tema)}"</li>
      <li><strong>Desenvolvimento:</strong> Explique o problema, mostre a solução em 2-3 passos práticos ligados a ${escapeHtml(tema)}</li>
      <li><strong>Prova:</strong> Um exemplo real ou resultado rápido</li>
      <li><strong>CTA:</strong> "Segue pra mais conteúdo assim" ou "Comenta se quer o passo a passo completo"</li>
    </ul>`;
  } else if (formato === 'titulo') {
    corpo = `<ul>
      <li>3 formas de resolver ${escapeHtml(tema)} sem complicação</li>
      <li>O erro que quase todo mundo comete em ${escapeHtml(tema)}</li>
      <li>Como eu resolvo ${escapeHtml(tema)} na prática</li>
    </ul>`;
  } else if (formato === 'descricao') {
    corpo = `<div class="resultado-card-body-texto">Neste conteúdo eu falo sobre ${escapeHtml(tema)} de forma direta, sem enrolação — ideal pra quem quer aplicar hoje mesmo. Salva pra assistir de novo e me segue pra mais conteúdos assim.</div>`;
  } else if (formato === 'gancho') {
    corpo = `<ul>
      <li>"Ninguém te conta isso sobre ${escapeHtml(tema)}..."</li>
      <li>"Parei de fazer isso e meus resultados mudaram"</li>
      <li>"3 segundos pra mudar como você vê ${escapeHtml(tema)}"</li>
    </ul>`;
  } else if (formato === 'cena') {
    corpo = `<ul>
      <li><strong>Cena 1:</strong> Close no rosto, gancho falado direto pra câmera</li>
      <li><strong>Cena 2:</strong> Tela/produto mostrando ${escapeHtml(tema)} na prática</li>
      <li><strong>Cena 3:</strong> Resultado ou prova social</li>
      <li><strong>Cena 4:</strong> CTA final com texto na tela</li>
    </ul>`;
  } else if (formato === 'educativo') {
    corpo = `<div class="resultado-card-body-texto">Estrutura sugerida: apresente 1 conceito sobre ${escapeHtml(tema)}, explique o "porquê" por trás dele, dê um exemplo prático e feche convidando o público a aplicar e comentar o resultado.</div>`;
  } else {
    corpo = `<div class="resultado-card-body-texto">Estrutura comercial: mostre a dor relacionada a ${escapeHtml(tema)}, apresente sua solução como o caminho mais direto, reforce com prova social e feche com uma chamada clara para ação.</div>`;
  }

  const card = document.createElement('div');
  card.className = 'resultado-card';
  card.innerHTML = `<div class="resultado-card-header"><span>${ROTULOS_FORMATO_ESTUDIO[formato]}</span></div><div class="resultado-card-body">${corpo}</div>`;
  container.prepend(card);
  registrarConteudoRecente(ROTULOS_FORMATO_ESTUDIO[formato], 'Estúdio de Conteúdo');
  if (window.lucide) lucide.createIcons();
}

// ==========================================================================
// RADAR DE NEGÓCIOS
// ==========================================================================

const BASE_OPORTUNIDADES_RADAR = [
  { chave: ['edição de vídeo', 'edicao de video', 'video'], oportunidades: ['Edição para criadores de conteúdo', 'Edição para empresas e institucionais', 'Criação de Reels/Shorts', 'Gerenciamento de conteúdo em vídeo', 'Produção de vídeos comerciais'] },
  { chave: ['design', 'identidade visual', 'branding'], oportunidades: ['Identidade visual para pequenos negócios', 'Social media design', 'Design de embalagens', 'Apresentações e materiais comerciais'] },
  { chave: ['copywriting', 'redação', 'copy'], oportunidades: ['Copy para landing pages', 'Roteiros de vendas', 'E-mail marketing', 'Copy para anúncios pagos'] },
  { chave: ['marketing', 'tráfego', 'trafego'], oportunidades: ['Gestão de tráfego pago', 'Consultoria de marketing digital', 'Gestão de redes sociais', 'Estratégia de lançamento'] },
  { chave: ['tecnologia', 'programação', 'programacao', 'desenvolvimento'], oportunidades: ['Desenvolvimento de sites institucionais', 'Automação de processos', 'Landing pages sob demanda', 'Manutenção de sistemas para pequenas empresas'] },
  { chave: ['consultoria', 'gestão', 'gestao', 'financeiro'], oportunidades: ['Consultoria financeira para autônomos', 'Organização de processos internos', 'Diagnóstico de precificação'] },
  { chave: ['fotografia', 'foto'], oportunidades: ['Fotografia de produtos', 'Ensaios para redes sociais de marcas', 'Cobertura de eventos corporativos'] }
];

function gerarRadarNegocios(event) {
  event.preventDefault();
  const perfil = carregarPerfil() || {};
  const habilidadesInput = document.getElementById('radarHabilidades').value.trim() || perfil.habilidades || '';
  const interesses = document.getElementById('radarInteresses').value.trim();
  const experiencia = document.getElementById('radarExperiencia').value;
  const disponibilidade = document.getElementById('radarDisponibilidade').value;
  const objetivo = document.getElementById('radarObjetivo').value.trim();

  const textoBusca = (habilidadesInput + ' ' + interesses).toLowerCase();
  let encontradas = [];

  BASE_OPORTUNIDADES_RADAR.forEach(bloco => {
    if (bloco.chave.some(k => textoBusca.includes(k))) {
      encontradas = encontradas.concat(bloco.oportunidades);
    }
  });

  if (encontradas.length === 0) {
    encontradas = ['Consultoria especializada na sua área de atuação', 'Criação de conteúdo educativo sobre o seu tema', 'Mentoria/assessoria pontual para quem está começando', 'Pacote de serviço recorrente mensal'];
  }

  const rotulosExp = { iniciante: 'iniciante', intermediario: 'intermediário', avancado: 'avançado' };
  const rotulosDisp = { parcial: 'até 15h/semana', media: '15h a 30h/semana', integral: 'mais de 30h/semana' };

  const container = document.getElementById('radarResultadoContainer');
  const card = document.createElement('div');
  card.className = 'resultado-card';
  card.innerHTML = `
    <div class="resultado-card-header"><span>Oportunidades mapeadas · Perfil ${rotulosExp[experiencia]}, ${rotulosDisp[disponibilidade]}</span></div>
    <div class="resultado-card-body">
      <p style="margin:0 0 12px;">A partir de "${escapeHtml(habilidadesInput || 'suas habilidades')}"${interesses ? ' e interesse em ' + escapeHtml(interesses) : ''}, estas são possíveis oportunidades:</p>
      <ul>${encontradas.map(o => `<li>${o}</li>`).join('')}</ul>
      ${objetivo ? `<p style="margin-top:12px;">Para atingir R$ ${escapeHtml(objetivo)}/mês, considere combinar 2 a 3 dessas frentes em paralelo.</p>` : ''}
    </div>
  `;
  container.prepend(card);
  registrarConteudoRecente('Mapeamento de oportunidades', 'Radar de Negócios');
  if (window.lucide) lucide.createIcons();
}

// ==========================================================================
// RADAR DE OPORTUNIDADES (mock de nichos/tendências)
// ==========================================================================

const OPORTUNIDADES_MERCADO = [
  { nicho: 'Social media para pequenos negócios locais', categoria: 'marketing', indicador: 'alta', texto: 'Alta demanda' },
  { nicho: 'Identidade visual para infoprodutores', categoria: 'design', indicador: 'crescimento', texto: 'Em crescimento' },
  { nicho: 'Automação de atendimento via WhatsApp', categoria: 'tecnologia', indicador: 'crescimento', texto: 'Em crescimento' },
  { nicho: 'Consultoria de precificação para freelancers', categoria: 'consultoria', indicador: 'alta', texto: 'Alta demanda' },
  { nicho: 'Roteirização de vídeos curtos para marcas', categoria: 'conteudo', indicador: 'alta', texto: 'Alta demanda' },
  { nicho: 'Landing pages para lançamentos', categoria: 'tecnologia', indicador: 'sazonal', texto: 'Sazonal (picos em lançamentos)' },
  { nicho: 'Gestão de tráfego pago para e-commerce pequeno', categoria: 'marketing', indicador: 'alta', texto: 'Alta demanda' },
  { nicho: 'Organização financeira para autônomos', categoria: 'consultoria', indicador: 'crescimento', texto: 'Em crescimento' },
  { nicho: 'Design de apresentações comerciais', categoria: 'design', indicador: 'sazonal', texto: 'Sazonal (fim/início de trimestre)' },
  { nicho: 'Produção de conteúdo educativo em vídeo', categoria: 'conteudo', indicador: 'crescimento', texto: 'Em crescimento' }
];

function renderizarOportunidades(categoria) {
  const grid = document.getElementById('oportunidadesGrid');
  if (!grid) return;
  grid.innerHTML = '';
  const filtradas = categoria === 'todos' ? OPORTUNIDADES_MERCADO : OPORTUNIDADES_MERCADO.filter(o => o.categoria === categoria);
  filtradas.forEach(o => {
    const card = document.createElement('div');
    card.className = 'oportunidade-card';
    card.innerHTML = `
      <div class="oportunidade-card-top">
        <h5>${o.nicho}</h5>
        <span class="badge-indicador ${o.indicador}">${o.texto}</span>
      </div>
      <p>Categoria: ${o.categoria.charAt(0).toUpperCase() + o.categoria.slice(1)}</p>
    `;
    grid.appendChild(card);
  });
}

function filtrarOportunidades(botao) {
  document.querySelectorAll('#filtroOportunidades .filtro-chip').forEach(b => b.classList.remove('active'));
  botao.classList.add('active');
  renderizarOportunidades(botao.dataset.categoria);
}

// ==========================================================================
// GERADOR DE PROPOSTAS
// ==========================================================================

const PROPOSTAS_KEY = 'marcaviva_propostas';

function carregarPropostas() {
  try { return JSON.parse(localStorage.getItem(PROPOSTAS_KEY) || '[]'); } catch (e) { return []; }
}

function montarTextoProposta(dados) {
  const perfil = carregarPerfil() || {};
  return `PROPOSTA COMERCIAL

Cliente: ${dados.cliente}
${perfil.profissao ? 'Prestador: ' + perfil.profissao : ''}

Serviço: ${dados.servico}

Descrição do escopo:
${dados.descricao || 'A combinar com o cliente conforme necessidade.'}

Prazo de entrega: ${dados.prazo || 'A combinar'}

Investimento: R$ ${dados.preco || 'A combinar'}

Condições de pagamento: ${dados.condicoes || 'A combinar'}

Esta proposta é válida por 7 dias a partir da data de envio.`;
}

function gerarProposta(event) {
  event.preventDefault();
  const dados = {
    cliente: document.getElementById('propostaCliente').value.trim(),
    servico: document.getElementById('propostaServico').value.trim(),
    descricao: document.getElementById('propostaDescricao').value.trim(),
    prazo: document.getElementById('propostaPrazo').value.trim(),
    preco: document.getElementById('propostaPreco').value.trim(),
    condicoes: document.getElementById('propostaCondicoes').value.trim()
  };

  const texto = montarTextoProposta(dados);
  const container = document.getElementById('propostaResultadoContainer');
  container.innerHTML = `
    <div class="copy-card">
      <div class="copy-card-header">
        <h5>Proposta gerada — ${escapeHtml(dados.cliente)}</h5>
        <div style="display:flex; gap:8px;">
          <button class="btn-copy" onclick="copiarTexto(this)"><i data-lucide="copy"></i> Copiar</button>
          <button class="btn-copy" onclick="exportarPropostaPDF(this)"><i data-lucide="download"></i> PDF</button>
          <button class="btn-copy" onclick="salvarPropostaAtual()"><i data-lucide="save"></i> Salvar</button>
        </div>
      </div>
      <div class="copy-card-body" id="propostaTextoAtual" contenteditable="true" style="font-style: normal; white-space: pre-wrap;">${escapeHtml(texto)}</div>
    </div>
  `;
  window._propostaAtualDados = dados;
  registrarConteudoRecente('Proposta para ' + dados.cliente, 'Gerador de Propostas');
  if (window.lucide) lucide.createIcons();
}

function exportarPropostaPDF(botao) {
  const el = document.getElementById('propostaTextoAtual');
  if (window.html2pdf && el) {
    html2pdf().set({ filename: 'proposta-marcaviva.pdf', margin: 14 }).from(el).save();
  }
}

function salvarPropostaAtual() {
  const el = document.getElementById('propostaTextoAtual');
  if (!el || !window._propostaAtualDados) return;
  const propostas = carregarPropostas();
  propostas.unshift({ cliente: window._propostaAtualDados.cliente, servico: window._propostaAtualDados.servico, texto: el.textContent, data: new Date().toLocaleDateString('pt-BR') });
  localStorage.setItem(PROPOSTAS_KEY, JSON.stringify(propostas));
  renderizarPropostasSalvas();
}

function renderizarPropostasSalvas() {
  const container = document.getElementById('propostasSalvasContainer');
  const vazio = document.getElementById('propostasSalvasVazio');
  if (!container) return;
  const propostas = carregarPropostas();
  container.innerHTML = '';
  vazio.style.display = propostas.length ? 'none' : 'block';
  propostas.forEach((p, i) => {
    const item = document.createElement('div');
    item.className = 'overview-list-item';
    item.innerHTML = `<div class="overview-list-item-main"><strong>${escapeHtml(p.cliente)}</strong><span>${escapeHtml(p.servico)} · ${p.data}</span></div>
      <button class="kanban-card-remove" onclick="removerProposta(${i})"><i data-lucide="trash-2"></i></button>`;
    container.appendChild(item);
  });
  if (window.lucide) lucide.createIcons();
}

function removerProposta(indice) {
  const propostas = carregarPropostas();
  propostas.splice(indice, 1);
  localStorage.setItem(PROPOSTAS_KEY, JSON.stringify(propostas));
  renderizarPropostasSalvas();
}

// ==========================================================================
// ORGANIZADOR DE PROJETOS — KANBAN
// ==========================================================================

const TAREFAS_KEY = 'marcaviva_kanban';

function carregarTarefas() {
  try {
    const bruto = localStorage.getItem(TAREFAS_KEY);
    if (bruto) return JSON.parse(bruto);
  } catch (e) { /* ignora */ }
  const seed = [
    { id: 't1', titulo: 'Enviar proposta comercial', cliente: 'Studio Bella', prazo: '', prioridade: 'alta', coluna: 'backlog', descricao: '' },
    { id: 't2', titulo: 'Criar posts da semana', cliente: 'Café Raiz', prazo: '', prioridade: 'media', coluna: 'andamento', descricao: '' },
    { id: 't3', titulo: 'Revisar identidade visual', cliente: 'Loja Nova', prazo: '', prioridade: 'media', coluna: 'revisao', descricao: '' },
    { id: 't4', titulo: 'Entrega final do site', cliente: 'Consultório Vida', prazo: '', prioridade: 'baixa', coluna: 'concluido', descricao: '' }
  ];
  localStorage.setItem(TAREFAS_KEY, JSON.stringify(seed));
  return seed;
}

function salvarTarefas(tarefas) {
  localStorage.setItem(TAREFAS_KEY, JSON.stringify(tarefas));
}

function abrirModalTarefa() {
  document.getElementById('modalTarefa').style.display = 'flex';
}

function fecharModalTarefa() {
  document.getElementById('modalTarefa').style.display = 'none';
  document.querySelector('#modalTarefa form').reset();
}

function salvarNovaTarefa(event) {
  event.preventDefault();
  const tarefas = carregarTarefas();
  tarefas.push({
    id: 't' + Date.now(),
    titulo: document.getElementById('tarefaTitulo').value.trim(),
    cliente: document.getElementById('tarefaCliente').value.trim(),
    prazo: document.getElementById('tarefaPrazo').value,
    prioridade: document.getElementById('tarefaPrioridade').value,
    coluna: document.getElementById('tarefaColuna').value,
    descricao: document.getElementById('tarefaDescricao').value.trim()
  });
  salvarTarefas(tarefas);
  fecharModalTarefa();
  renderizarKanban();
}

function removerTarefa(id) {
  const tarefas = carregarTarefas().filter(t => t.id !== id);
  salvarTarefas(tarefas);
  renderizarKanban();
}

const COLUNAS_KANBAN = {
  backlog: { elId: 'colBacklog', countId: 'countBacklog' },
  andamento: { elId: 'colAndamento', countId: 'countAndamento' },
  revisao: { elId: 'colRevisao', countId: 'countRevisao' },
  concluido: { elId: 'colConcluido', countId: 'countConcluido' }
};

function renderizarKanban() {
  const tarefas = carregarTarefas();
  Object.keys(COLUNAS_KANBAN).forEach(colKey => {
    const el = document.getElementById(COLUNAS_KANBAN[colKey].elId);
    if (!el) return;
    el.innerHTML = '';
  });

  tarefas.forEach(t => {
    const destino = COLUNAS_KANBAN[t.coluna] ? t.coluna : 'backlog';
    const el = document.getElementById(COLUNAS_KANBAN[destino].elId);
    const card = document.createElement('div');
    card.className = 'kanban-card';
    card.draggable = true;
    card.dataset.id = t.id;
    card.ondragstart = arrastarInicio;
    card.ondragend = arrastarFim;
    card.innerHTML = `
      <div class="kanban-card-top">
        <strong>${escapeHtml(t.titulo)}</strong>
        <button class="kanban-card-remove" onclick="removerTarefa('${t.id}')"><i data-lucide="trash-2"></i></button>
      </div>
      ${t.descricao ? `<p style="margin:0 0 6px; font-size:12px; color: var(--text-secondary);">${escapeHtml(t.descricao)}</p>` : ''}
      <div class="kanban-card-meta">
        <span class="badge-prioridade ${t.prioridade}">${t.prioridade}</span>
        ${t.cliente ? `<span class="badge-meta-info"><i data-lucide="user"></i>${escapeHtml(t.cliente)}</span>` : ''}
        ${t.prazo ? `<span class="badge-meta-info"><i data-lucide="calendar"></i>${t.prazo}</span>` : ''}
      </div>
    `;
    el.appendChild(card);
  });

  Object.keys(COLUNAS_KANBAN).forEach(colKey => {
    const count = tarefas.filter(t => t.coluna === colKey).length;
    document.getElementById(COLUNAS_KANBAN[colKey].countId).textContent = count;
  });

  if (window.lucide) lucide.createIcons();
}

function arrastarInicio(event) {
  event.dataTransfer.setData('text/plain', event.currentTarget.dataset.id);
  event.currentTarget.classList.add('dragging');
}

function arrastarFim(event) {
  event.currentTarget.classList.remove('dragging');
}

function permitirDrop(event) {
  event.preventDefault();
  event.currentTarget.classList.add('drag-over');
}

function dropTarefa(event, coluna) {
  event.preventDefault();
  event.currentTarget.classList.remove('drag-over');
  const id = event.dataTransfer.getData('text/plain');
  const tarefas = carregarTarefas();
  const tarefa = tarefas.find(t => t.id === id);
  if (tarefa) {
    tarefa.coluna = coluna;
    salvarTarefas(tarefas);
    renderizarKanban();
  }
}

document.addEventListener('dragleave', (event) => {
  if (event.target.classList && event.target.classList.contains('kanban-cards')) {
    event.target.classList.remove('drag-over');
  }
});

// ==========================================================================
// CALCULADORA PJ
// ==========================================================================

function calcularPJ(event) {
  event.preventDefault();
  const meta = parseFloat(document.getElementById('calcMeta').value) || 0;
  const despesas = parseFloat(document.getElementById('calcDespesas').value) || 0;
  const horasSemana = parseFloat(document.getElementById('calcHorasSemana').value) || 1;
  const pctFaturavel = (parseFloat(document.getElementById('calcPctFaturavel').value) || 70) / 100;
  const margem = (parseFloat(document.getElementById('calcMargem').value) || 0) / 100;
  const horasProjeto = parseFloat(document.getElementById('calcHorasProjeto').value) || 1;

  const horasFaturaveisMes = horasSemana * 4.33 * pctFaturavel;
  const baseCusto = meta + despesas;
  const valorHora = horasFaturaveisMes > 0 ? (baseCusto * (1 + margem)) / horasFaturaveisMes : 0;
  const precoProjeto = valorHora * horasProjeto;
  const clientesNecessarios = precoProjeto > 0 ? Math.ceil(meta / precoProjeto) : 0;
  const horasNecessarias = clientesNecessarios * horasProjeto;
  const valorMinimo = valorHora * 1.15;

  const formatarMoeda = (v) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const container = document.getElementById('calcResultadoContainer');
  container.innerHTML = `
    <div class="metric-box">
      <span class="metric-title">Valor da Hora</span>
      <span class="metric-value-text">${formatarMoeda(valorHora)}</span>
      <p class="metric-subtext">Considerando ${Math.round(horasFaturaveisMes)}h faturáveis/mês</p>
    </div>
    <div class="metric-box">
      <span class="metric-title">Preço de Projeto (médio)</span>
      <span class="metric-value-text">${formatarMoeda(precoProjeto)}</span>
      <p class="metric-subtext">Para projetos de ${horasProjeto}h</p>
    </div>
    <div class="metric-box">
      <span class="metric-title">Clientes Necessários no Mês</span>
      <span class="metric-value-text">${clientesNecessarios}</span>
      <p class="metric-subtext">Para atingir a meta de ${formatarMoeda(meta)}</p>
    </div>
    <div class="metric-box">
      <span class="metric-title">Horas Necessárias no Mês</span>
      <span class="metric-value-text">${Math.round(horasNecessarias)}h</span>
      <p class="metric-subtext">Com base nos clientes necessários</p>
    </div>
    <div class="metric-box">
      <span class="metric-title">Valor Mínimo Recomendado / Hora</span>
      <span class="metric-value-text">${formatarMoeda(valorMinimo)}</span>
      <p class="metric-subtext">Com margem extra de segurança de 15%</p>
    </div>
  `;
}

// ==========================================================================
// INICIALIZAÇÃO
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
  atualizarContextoPerfil();
  renderizarKanban();
  renderizarPropostasSalvas();
  renderizarOportunidades('todos');
  atualizarVisaoGeral();
  if (window.lucide) lucide.createIcons();
});

if (window.lucide) lucide.createIcons();
