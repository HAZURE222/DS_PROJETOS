// ==========================================================================
// THEME.JS — alterna e persiste o tema (claro/escuro) em todas as páginas
// da MarcaViva. Deve ser incluído no <head>, antes do CSS, para aplicar o
// tema salvo imediatamente e evitar "flash" de tema errado.
// ==========================================================================

(function () {
  var CHAVE_TEMA = 'marcaviva_tema';

  function temaSalvo() {
    try {
      return localStorage.getItem(CHAVE_TEMA) || 'claro';
    } catch (e) {
      return 'claro';
    }
  }

  function aplicarTema(tema) {
    document.documentElement.setAttribute('data-theme', tema);
  }

  // Aplica o tema salvo o quanto antes (antes do primeiro paint).
  aplicarTema(temaSalvo());

  // Alterna entre claro/escuro e persiste a escolha.
  window.alternarTema = function () {
    var atual = document.documentElement.getAttribute('data-theme') || 'claro';
    var novo = atual === 'escuro' ? 'claro' : 'escuro';
    try {
      localStorage.setItem(CHAVE_TEMA, novo);
    } catch (e) { /* localStorage indisponível — segue apenas em memória */ }
    aplicarTema(novo);
    atualizarTextoBotao(novo);
  };

  function atualizarTextoBotao(tema) {
    var label = document.getElementById('temaBotaoTexto');
    if (label) {
      label.textContent = tema === 'escuro' ? 'Tema Claro' : 'Tema Escuro';
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    atualizarTextoBotao(temaSalvo());
    if (window.lucide) {
      lucide.createIcons();
    }
  });
})();
