#!/usr/bin/env python3
# ==============================================================================
# MARCAVIVA — AGENTE MENTOR IA (processamento local)
# ==============================================================================
#
# Este script É o agente de IA que conversa com o usuário no chat "Mentor IA
# Especialista" do painel. Ele NÃO depende de uma API de IA paga por token:
#
#   1) Primeiro tenta falar com uma instância local do OLLAMA
#      (https://ollama.com), que roda o modelo de linguagem inteiramente na
#      máquina do usuário/servidor, usando o processamento (CPU/GPU) local.
#
#   2) Se o Ollama não estiver instalado ou não estiver rodando, o agente
#      cai automaticamente para um mecanismo heurístico escrito em Python
#      puro (sem nenhuma chamada de rede), que também roda só com o
#      processamento do computador.
#
# Uso:
#   O server.js chama este arquivo como um subprocesso, envia um JSON pelo
#   stdin e lê a resposta (JSON) pelo stdout. Também dá pra testar direto
#   pelo terminal:
#
#   echo '{"mensagem": "Como conseguir clientes?", "historico": [], "perfil": {}}' \
#     | python3 agente_mentor_ia.py
#
# Variáveis de ambiente opcionais:
#   OLLAMA_HOST   -> endereço do servidor Ollama (padrão: http://localhost:11434)
#   OLLAMA_MODEL  -> modelo a ser usado (padrão: llama3.1)
#   OLLAMA_TIMEOUT -> timeout em segundos para aguardar o Ollama (padrão: 30)
# ==============================================================================

import sys
import os
import json
import urllib.request
import urllib.error


OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.1")
OLLAMA_TIMEOUT = float(os.environ.get("OLLAMA_TIMEOUT", "30"))

PERSONA_SISTEMA = (
    "Você é o 'Mentor Estratégico AI' do MarcaViva, um consultor de negócios "
    "especialista em ajudar profissionais liberais, freelancers, autônomos e "
    "prestadores de serviço PJ. Responda sempre em português do Brasil, de forma "
    "direta, prática e acionável — evite enrolação e prefira listas curtas de "
    "passos concretos. Seus temas fortes são: precificação, conquista de clientes, "
    "organização da rotina de trabalho, criação de novos produtos/serviços, "
    "posicionamento de marca e marketing. Quando fizer sentido, sugira o uso das "
    "outras ferramentas do painel MarcaViva (Calculadora PJ, Organizador de "
    "Projetos, Gerador de Propostas, Radar de Negócios, Copys Magnéticas, "
    "Impulsionador Social, Arquétipo Prático)."
)


def montar_contexto_perfil(perfil):
    """Transforma o Perfil do Negócio (dict vindo do front-end) em uma frase
    de contexto para o modelo levar em conta."""
    if not perfil:
        return ""
    partes = []
    if perfil.get("area"):
        partes.append(f"área de atuação: {perfil['area']}")
    if perfil.get("profissao"):
        partes.append(f"profissão: {perfil['profissao']}")
    if perfil.get("servicos"):
        partes.append(f"serviços oferecidos: {perfil['servicos']}")
    if perfil.get("publico"):
        partes.append(f"público-alvo: {perfil['publico']}")
    if perfil.get("objetivo"):
        partes.append(f"objetivo atual: {perfil['objetivo']}")
    if perfil.get("faixaPreco"):
        partes.append(f"faixa de preço praticada: {perfil['faixaPreco']}")
    if not partes:
        return ""
    return "Contexto do negócio do usuário -> " + "; ".join(partes) + "."


# ------------------------------------------------------------------------------
# CAMINHO 1: OLLAMA (processamento local via modelo de linguagem)
# ------------------------------------------------------------------------------

def perguntar_ao_ollama(mensagem, historico, perfil):
    """Envia a conversa para uma instância local do Ollama. Levanta exceção
    se o Ollama não estiver disponível, o que aciona o fallback heurístico."""

    mensagens = [{"role": "system", "content": PERSONA_SISTEMA}]

    contexto = montar_contexto_perfil(perfil)
    if contexto:
        mensagens.append({"role": "system", "content": contexto})

    for item in (historico or [])[-12:]:
        autor = item.get("autor")
        texto = item.get("texto")
        if not texto:
            continue
        role = "assistant" if autor == "bot" else "user"
        mensagens.append({"role": role, "content": texto})

    mensagens.append({"role": "user", "content": mensagem})

    payload = json.dumps({
        "model": OLLAMA_MODEL,
        "messages": mensagens,
        "stream": False
    }).encode("utf-8")

    requisicao = urllib.request.Request(
        f"{OLLAMA_HOST}/api/chat",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    with urllib.request.urlopen(requisicao, timeout=OLLAMA_TIMEOUT) as resposta:
        corpo = json.loads(resposta.read().decode("utf-8"))
        texto_resposta = (corpo.get("message") or {}).get("content", "").strip()
        if not texto_resposta:
            raise ValueError("Ollama respondeu sem conteúdo utilizável.")
        return texto_resposta


# ------------------------------------------------------------------------------
# CAMINHO 2: FALLBACK HEURÍSTICO (100% local, sem rede, sem tokens)
# ------------------------------------------------------------------------------

def gerar_resposta_heuristica(mensagem, perfil):
    """Mecanismo de regras em Python puro. É o mesmo raciocínio que antes
    vivia no JavaScript do front-end, agora rodando no back-end como parte
    do agente, sem depender de nenhuma API externa."""

    # Frase de abertura mais natural com o contexto do perfil, se houver:
    abertura = ""
    if perfil and perfil.get("area"):
        abertura = f"Considerando sua atuação em {perfil['area']}"
        if perfil.get("servicos"):
            abertura += f" com foco em {perfil['servicos']}"
        abertura += ", "

    texto = (mensagem or "").lower()

    if any(p in texto for p in ("client", "captar", "vender")):
        return (
            f"{abertura}recomendo três frentes simultâneas: (1) ative sua rede "
            "próxima com uma mensagem direta oferecendo um diagnóstico gratuito, "
            "(2) publique 3x por semana mostrando processo e resultados no "
            "Impulsionador Social, e (3) monte uma proposta padrão no Gerador de "
            "Propostas para responder rápido a quem demonstrar interesse."
        )

    if any(p in texto for p in ("preç", "prec", "valor", "cobra", "orçamento", "orcamento")):
        return (
            f"{abertura}use a Calculadora PJ para descobrir seu valor de hora real "
            "(considerando despesas fixas e margem) e, a partir dele, monte "
            "pacotes fechados em vez de cobrar só por hora — isso aumenta o valor "
            "percebido pelo cliente."
        )

    if any(p in texto for p in ("organiz", "semana", "produtividade", "rotina", "agenda")):
        return (
            f"{abertura}sugiro estruturar sua semana em blocos: 2 dias para "
            "entrega de clientes, 1 dia para prospecção/marketing e 1 bloco fixo "
            "para administrativo. Use o Organizador de Projetos para visualizar "
            "tudo em colunas de Backlog, Em Andamento, Em Revisão e Concluído."
        )

    if any(p in texto for p in ("novo serviço", "novo servico", "produto", "oferecer", "escalar")):
        return (
            f"{abertura}olhe para o que você já entrega com mais facilidade e "
            "transforme em um novo formato: um serviço pontual pode virar um "
            "pacote recorrente, uma entrega pode virar um mini-curso ou "
            "consultoria. O Radar de Negócios pode sugerir combinações a partir "
            "das suas habilidades."
        )

    if any(p in texto for p in ("posiciona", "marca", "identidade")):
        return (
            f"{abertura}revise o Arquétipo Prático e a Neuro-Cromática do seu "
            "perfil: seu posicionamento deve refletir consistentemente as mesmas "
            "cores, tom de voz e promessa em todos os canais de comunicação."
        )

    pergunta_segura = (mensagem or "").strip() or "sua dúvida"
    return (
        f"{abertura}entendi sua pergunta sobre \"{pergunta_segura}\". Posso ajudar "
        "com decisões de negócio, precificação, estratégias para conseguir "
        "clientes, organização, planejamento, posicionamento, marketing e "
        "criação de produtos/serviços. Me dê mais detalhes para eu aprofundar a "
        "resposta."
    )


# ------------------------------------------------------------------------------
# PONTO DE ENTRADA
# ------------------------------------------------------------------------------

def processar(entrada):
    mensagem = (entrada.get("mensagem") or "").strip()
    historico = entrada.get("historico") or []
    perfil = entrada.get("perfil") or {}

    if not mensagem:
        return {"resposta": "Pode escrever sua dúvida que eu te ajudo.", "fonte": "local"}

    try:
        resposta = perguntar_ao_ollama(mensagem, historico, perfil)
        return {"resposta": resposta, "fonte": "ollama", "modelo": OLLAMA_MODEL}
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError, ValueError, json.JSONDecodeError):
        # Ollama indisponível (não instalado, não rodando, timeout, etc.)
        # -> segue no processamento 100% local, sem rede e sem tokens.
        resposta = gerar_resposta_heuristica(mensagem, perfil)
        return {"resposta": resposta, "fonte": "local"}


def main():
    bruto = sys.stdin.read()
    try:
        entrada = json.loads(bruto) if bruto.strip() else {}
    except json.JSONDecodeError:
        entrada = {}

    saida = processar(entrada)
    sys.stdout.write(json.dumps(saida, ensure_ascii=False))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
